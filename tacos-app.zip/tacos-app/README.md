# 🌮 TacoApp — Angular + Node + PostgreSQL

## Estructura
```
tacos-app/
├── backend/          ← Node.js + Express + PostgreSQL
└── frontend/         ← Angular (archivos a copiar en tu proyecto)
```

---

## 🗄️ 1. Configurar PostgreSQL

1. Crea la base de datos:
```sql
CREATE DATABASE tacosdb;
```

2. Ejecuta el schema:
```bash
psql -U postgres -d tacosdb -f backend/schema.sql
```

---

## ⚙️ 2. Backend (Node.js)

```bash
cd backend
cp .env.example .env
# Edita .env con tu contraseña de PostgreSQL
npm install
npm run dev
```
Servidor en: http://localhost:3000

---

## 🅰️ 3. Frontend (Angular)

```bash
# Si no tienes Angular CLI:
npm install -g @angular/cli

# Crea proyecto nuevo
ng new tacos-front --routing --style=css
cd tacos-front

# Copia los archivos de frontend/src/ a tu proyecto
# Reemplaza src/app/ y src/styles.css
# Copia src/environments/

npm install
ng serve
```
App en: http://localhost:4200

---

## 🔑 Credenciales de prueba
- Email: `admin@tacos.com`
- Password: `tacos123`

---

## 📡 Endpoints API
| Método | Ruta | Auth |
|--------|------|------|
| POST | /api/auth/login | No |
| GET  | /api/ordenes/mi-orden | Bearer JWT |
