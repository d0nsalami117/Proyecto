-- Crear base de datos
-- CREATE DATABASE tacosdb;

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
  id SERIAL PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Tabla de ordenes
CREATE TABLE IF NOT EXISTS ordenes (
  id SERIAL PRIMARY KEY,
  usuario_id INTEGER REFERENCES usuarios(id),
  estado VARCHAR(50) DEFAULT 'lista',
  total DECIMAL(10,2),
  fecha TIMESTAMP DEFAULT NOW()
);

-- Tabla de items de la orden
CREATE TABLE IF NOT EXISTS orden_items (
  id SERIAL PRIMARY KEY,
  orden_id INTEGER REFERENCES ordenes(id),
  taco VARCHAR(100) NOT NULL,
  cantidad INTEGER NOT NULL,
  precio DECIMAL(10,2) NOT NULL
);

-- Usuario de prueba (password: tacos123)
INSERT INTO usuarios (nombre, email, password) VALUES
  ('Don Taquero', 'admin@tacos.com', '$2a$10$xK6.Y/UHRe.3A0pnp9kzwuG5yC1pYZqq4V8MrMKBJqOCZxH0R3uCy')
ON CONFLICT (email) DO NOTHING;

-- Orden de ejemplo
INSERT INTO ordenes (usuario_id, estado, total) VALUES
  (1, 'lista', 95.00);

INSERT INTO orden_items (orden_id, taco, cantidad, precio) VALUES
  (1, 'Taco de Pastor', 3, 20.00),
  (1, 'Taco de Suadero', 2, 18.00),
  (1, 'Taco de Chorizo', 2, 17.50),
  (1, 'Agua de Horchata', 1, 22.00);
