const pool = require('../config/db');

const getOrden = async (req, res) => {
  try {
    const ordenResult = await pool.query(
      `SELECT o.*, u.nombre as cliente
       FROM ordenes o
       JOIN usuarios u ON u.id = o.usuario_id
       WHERE o.usuario_id = $1
       ORDER BY o.fecha DESC LIMIT 1`,
      [req.user.id]
    );

    if (ordenResult.rows.length === 0)
      return res.status(404).json({ message: 'No hay órdenes' });

    const orden = ordenResult.rows[0];

    const itemsResult = await pool.query(
      'SELECT * FROM orden_items WHERE orden_id = $1',
      [orden.id]
    );

    res.json({ orden, items: itemsResult.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error del servidor' });
  }
};

module.exports = { getOrden };
