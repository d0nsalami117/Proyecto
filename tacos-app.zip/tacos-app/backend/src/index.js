require('dotenv').config();
const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors({ origin: 'http://localhost:4200' }));
app.use(express.json());

app.use('/api/auth', require('./routes/auth'));
app.use('/api/ordenes', require('./routes/ordenes'));

app.get('/', (req, res) => res.json({ message: '🌮 Tacos API corriendo' }));

app.listen(PORT, () => console.log(`🚀 Servidor en http://localhost:${PORT}`));
