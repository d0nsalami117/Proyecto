const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const { getOrden } = require('../controllers/ordenController');

router.get('/mi-orden', authMiddleware, getOrden);

module.exports = router;
