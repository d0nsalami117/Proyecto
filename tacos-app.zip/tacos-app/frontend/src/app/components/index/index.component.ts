import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { OrdenService } from '../../services/orden.service';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {
  user: any = null;
  orden: any = null;
  items: any[] = [];
  loading = true;
  error = '';

  constructor(private auth: AuthService, private ordenService: OrdenService) {}

  ngOnInit() {
    this.user = this.auth.getUser();
    this.ordenService.getMiOrden().subscribe({
      next: (res) => {
        this.orden = res.orden;
        this.items = res.items;
        this.loading = false;
      },
      error: () => {
        this.error = 'No se pudo cargar la orden';
        this.loading = false;
      }
    });
  }

  logout() { this.auth.logout(); }
}
